<!-- Guida -->

Avviare "Verbi Latini.exe" in una macchina Windows.
All' alert di Benvenuto premere "OK" e attendere l' apparizione della home del programma.
A questo punto nel text box digitare l' infinito presente di un Verbo di 1� coniugazione
(amare, laudare... tutti i nomi uscenti per "are").
A questo punto selezionare il modo in cui coniugarlo e fare click sul pallino corrispondente
cos� da checkkarlo.
Ora fare click sul bottone "Coniuga".
Nella schermata a sinistra apparir� il verbo coniugato in tutti i tempi del rispettivo modo.

--------------------------------------------

<!-- Nella prossima versione... -->

-- Tutte le coniugazioni
-- Tempo Passivo
-- Nuova Interfaccia Grafica (GUI)
-- Possibilit� di stampare direttamente dal programma i verbi generati
-- Sfondo incluso nell' eseguibile

--------------------------------------------

<!-- Bug Conosciuti -->

-- Se si elimina o si sposta l' immagine "logo.jpg" non si potr� visualizzarlo nel programma




